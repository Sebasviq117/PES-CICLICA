

Vera Humana 95

This True Type Font was designed for Windows 95. Though we have
created it especially for using the cyrillic characters 
we have added the composite latin characters for East European 
languages, too, so that this font supports the codepages Cyr 
(1251), CE (1250) and Baltic (1257). You can use it for writing
Russian, Ukrainian and Serbian as well as Polish, Czech, Romanian, 
Hungarian, Slovenian, Latvian, Lithuanian etc.

For using cyrillic and composite latin characters Windows 95 
Multilanguage Support for the desired languages must be installed 
on your computer.
If you don't have the Multilinguage Support (it isn't supplied
on diskette version of Windows 95) you can download it from 
http://www.microsoft.com/windows/download/lang.exe.
In Keyboard Properties (Control Panel - Keyboard - Language) you
will have to add the desired languages.
Without Multilanguage support, or in Windows 3.1x you can use
only latin ANSI characters for West-European languages.

For use in some programmes like Word for Windows you must add the 
following lines to the file win.ini in section [FontSubstitutes]:

Vera Humana 95 Cyr,204=Vera Humana 95,204
Vera Humana 95 Baltic,186=Vera Humana 95,186
Vera Humana 95 CE,238=Vera Humana 95,238

(if you don't know what this is and how you can
do this, ask for help a friend who is fit with computers)

**************************************************************

Maybe, on low resolution printers (<600 dpi) the font
won't look very fine, because it has no straight lines. On a 
Epson Stylus 800, for instance, the result may be not satisfying, 
but on my HP DeskJet 400 it looks rather well (perhaps because of 
HP's RET System). The best quality you will achieve on typographic 
machines with high resolution (>1200 dpi).

***********************************************************






